using UnityEngine;
using System.Threading.Tasks;
using Whisper;
using Whisper.Utils;

public class KoreanSpeechManager : MonoBehaviour
{
    [SerializeField] private WhisperManager whisperManager;
    [SerializeField] private MicrophoneRecord microphoneRecord;
    [SerializeField] private GeminiClient gc;

    private bool _isRecording = false;

    private void OnEnable()
    {
        // Subscribe to the component's stop event
        if (microphoneRecord != null)
        {
            microphoneRecord.OnRecordStop += OnMicrophoneRecordStop;
        }
    }

    private void OnDisable()
    {
        // Unsubscribe to avoid memory leaks
        if (microphoneRecord != null)
        {
            microphoneRecord.OnRecordStop -= OnMicrophoneRecordStop;
        }
    }

    private async void Start()
    {
        if (whisperManager != null)
        {
            Debug.Log("Whisper �� �ε� ����...");

            // ���� ���� �� ���� �ε�� ������ ��ٸ��ϴ�.
            await whisperManager.InitModel();

            Debug.Log("Whisper �� �ε� �Ϸ�! ���� ������ �����մϴ�.");
        }
        else
        {
            Debug.LogError("WhisperManager�� ��ũ��Ʈ�� �Ҵ���� �ʾҽ��ϴ�!");
        }
    }

    async void Update()
    {
        // Press Spacebar to toggle recording
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (!_isRecording)
            {
                gc.StartListening();
                StartListening();
            }
            else
            {
                gc.StopListening();
                StopListening();
            }
        }
    }

    private void StartListening()
    {
        _isRecording = true;
        Debug.Log("Listening started... Speak in Korean.");

        if (microphoneRecord != null)
        {
            microphoneRecord.StartRecord();
        }
    }

    private void StopListening()
    {
        _isRecording = false;
        Debug.Log("Stopping microphone and preparing transcription...");

        if (microphoneRecord != null)
        {
            // This triggers the OnRecordStop event below
            microphoneRecord.StopRecord();
        }
    }

    // This callback receives the recorded data wrapper safely from the framework
    private async void OnMicrophoneRecordStop(AudioChunk recordedChunk)
    {
        Debug.Log("Processing Korean audio via Whisper...");

        // �⺻ ������ ��� static �޼���� �Ķ���͸� �����մϴ�.
        var paramsObj = WhisperParams.GetDefaultParams();
        paramsObj.Language = "ko"; // �ѱ��� ���� ����

        // Whisper ���۷��� ����
        var result = await whisperManager.GetTextAsync(recordedChunk.Data, recordedChunk.Frequency, recordedChunk.Channels);

        if (result != null)
        {
            Debug.Log($"Transcribed Text (KO): {result.Result}");
            gc.SendUserSpeech(result.Result);
        }
        else
        {
            Debug.LogError("Transcription failed.");
        }
    }
}